package cucumber.Options;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.junit.runner.RunWith;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import static io.restassured.RestAssured.*;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyData;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/features", plugin = "json:target/jsonReports/cucumber-report.json", glue = {
		"stepDefinitions" }, tags = "@1")
//@CucumberOptions(features="src/test/java/features/addTransactions.feature",plugin="json:target/jsonReports/cucumber-report.json",glue= {"stepDefinitions"})//,tags= "@AddPlace")
//@CucumberOptions(features="src/test/java/features/getTransactions.feature",plugin="json:target/jsonReports/cucumber-report.json",glue= {"stepDefinitions"})//,tags= "@AddPlace")

public class TestRunner {

//	@BeforeClass
//	public static void onceExecutedBeforeAll() throws IOException {
//		String deletePayload = System.getProperty("user.dir") + "\\DeleteTransaction.csv";
//		List<DeleteTransaction> summaryData = Utils.csvToObject(deletePayload, DeleteTransaction.class);
      
		/* @Author : Sameer 
		 * Log file code
		 */
		
//		String dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy").format(LocalDate.now());
//		String TName = Utils.getGlobalValue("testLogFile") + "t-eventLog-" + dateFormat + ".log";
//		PrintStream log = new PrintStream(new FileOutputStream(TName, true));

//		System.out.println("***Invoked URL***" + Utils.getGlobalValue("baseUrlDelete"));
//
//		for (DeleteTransaction transaction : summaryData) {
//			try {
//
//				transaction.setOrganizationCode(Utils.getGlobalValue("orgCode"));
//				Response response = RestAssured.given().baseUri(Utils.getGlobalValue("baseUrlDelete"))
//						//******Log file***********
//					//.filter(RequestLoggingFilter.logRequestTo(log)).filter(ResponseLoggingFilter.logResponseTo(log))
//						.contentType(ContentType.JSON).body(transaction)
//						.put(APIResources.DeleteTransaction.getResource());
//
//				String test = response.asString();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
}
	//Sujoy
//	static int buildValidationCounter;
//	@AfterClass
//	public static void afterClass() {
//		System.out.println("After Class");
//		
//		try {
//			buildValidationCounter = Integer.parseInt(Utils.getCounterValue("BuildValidation"));
//		} catch (NumberFormatException | IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		Utils.updateCounterValue(buildValidationCounter+1);
//}
	

