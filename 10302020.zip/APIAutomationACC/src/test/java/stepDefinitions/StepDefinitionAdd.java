package stepDefinitions;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.AddTransaction;
import static io.restassured.RestAssured.*;
import static org.junit.Assert.assertEquals;
import pojo.AddTransaction;
import resources.APIResources;
import resources.Utils;

public class StepDefinitionAdd extends Utils {
	
	List<RequestSpecification> requests = new ArrayList<RequestSpecification>();
	ResponseSpecification resspec;
	List<Response> responses = new ArrayList<Response>();
	public static String addscenarioName;
	
	@SuppressWarnings("static-access")
	@Given("{string} Accum Transaction Payload from CSV for {string}")
	public void add_accum_transaction_payload_from_csv_for(String requestType, String scenarioName) throws IOException {
		addscenarioName = scenarioName+"_Add";
		
		InputStream addPayload=this.getClass().getClassLoader().getSystemResourceAsStream("AddTransaction.csv");
		List<AddTransaction> summaryData = Utils.csvToObject(addPayload, AddTransaction.class);
		resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

		// Writing for loop for all the parameters from CSV: request payload
		// summaryData.stream().filter( transaction ->
		// transaction.getAccumName().equals('GET'))

		for (AddTransaction transaction : summaryData) {
			if (transaction.getClaimReasonText().equalsIgnoreCase(scenarioName)) {
				System.out.println("Add Scenarion >> " + addscenarioName + " is Matched");
				if(!scenarioName.equalsIgnoreCase("Invalid OrgCode")) {
					transaction.setOrganizationCode(getGlobalValue("orgCode"));
				}
			//	transaction.setOrganizationCode(getGlobalValue("orgCode"));
				requests.add(given().spec(requestSpecification(requestType,addscenarioName)).body(transaction));
			}
		}
		req = null;
	}

		@When("user calls {string} with {string} http request")
		public void user_calls_with_http_request(String resource, String method) {
		   // Write code here that turns the phrase above into concrete actions
			APIResources resourceAPI = APIResources.valueOf(resource);
		//	System.out.println(resourceAPI.getResource());
			resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
			
			for (RequestSpecification request : requests) {
				if (method.equalsIgnoreCase("POST"))
					responses.add(request.when().post(resourceAPI.getResource()));
				// responses =
				// res.when().post("/maps/api/place/add/json").then().spec(resspec).extract().responses();
				else if (method.equalsIgnoreCase("GET"))
					responses.add(request.when().get(resourceAPI.getResource()));
			}		     
		}
		
		@Then("the API call got success with status code {int}")
		public void the_api_call_got_success_with_status_code(Integer int1) {
		    // Write code here that turns the phrase above into concrete actions
			for(Response response: responses) {
			//	System.out.println(response.getStatusCode());
				if(addscenarioName.contains("Invalid")) {
					assertEquals(400,response.getStatusCode());	
				}
				else if(addscenarioName.contains("Incorrect")){
					assertEquals(404, response.getStatusCode());
				}
				else {
					
					assertEquals(200,response.getStatusCode());
				}
			}		
		}
		
		@Then("{string} in response  body is {string}")
		public void in_response_body_is(String keyValue, String expectedValue) {
		    // Write code here that turns the phrase above into concrete actions
			for(Response response: responses)
				assertEquals(getJsonPath(response, keyValue), expectedValue);
		} 
	}




