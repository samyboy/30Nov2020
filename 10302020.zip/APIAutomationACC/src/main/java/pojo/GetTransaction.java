package pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonProperty; 
import com.opencsv.bean.CsvBindByName;
@JsonAutoDetect(
		  fieldVisibility = Visibility.ANY,
		  getterVisibility = Visibility.NONE,
		  setterVisibility = Visibility.NONE,
		  creatorVisibility = Visibility.NONE
		) 
public class GetTransaction {
	

	@CsvBindByName(column = "OrganizationCode")
	private String OrganizationCode;
	
	@CsvBindByName(column = "MemberHCID")
	private String MemberHCID;
	
	@CsvBindByName(column = "MemberDepCd")
	private String MemberDepCd;
	
	@CsvBindByName(column = "MemberGrpId")
	private String MemberGrpId;
	
	@CsvBindByName(column = "MemberBenefitId")
	private String MemberBenefitId;
	
	@CsvBindByName(column = "AccumStartDate")
	private String AccumStartDate;
	
	@CsvBindByName(column = "AccumEndDate")
	private String AccumEndDate;
		
	@CsvBindByName(column = "ServiceStartDate")
	private String ServiceStartDate;
	
	@CsvBindByName(column = "ServiceEndDate")
	private String ServiceEndDate;
	
	@CsvBindByName(column = "ClaimNetwork")
	private String ClaimNetwork;
		
	@CsvBindByName(column = "AccumName")
	private String AccumName;
	
	@CsvBindByName(column = "MemberTier")
	private String MemberTier;
	
	@CsvBindByName(column = "ProviderTaxId")
	private String ProviderTaxId;
	
	@CsvBindByName(column = "DiagnosisCode")
	private String DiagnosisCode;
	
	@CsvBindByName(column = "ScenarioName")
	private String ScenarioName;
	
	@CsvBindByName(column = "ExpectedAmount")
	private String ExpectedAmount;
	
	
	
	public String getMemberDepCd() {
		return MemberDepCd;
	}

	public void setMemberDepCd(String memberDepCd) {
		this.MemberDepCd = memberDepCd;
	}

	public String getMemberGrpId() {
		return MemberGrpId;
	}

	public void setMemberGrpId(String memberGrpId) {
		this.MemberGrpId = memberGrpId;
	}

	public String getMemberBenefitId() {
		return MemberBenefitId;
	}

	public void setMemberBenefitId(String memberBenefitId) {
		this.MemberBenefitId = memberBenefitId;
	}

	public String getExpectedAmount() {
		return ExpectedAmount;
	}

	public void setExpectedAmount(String expectedAmount) {
		ExpectedAmount = expectedAmount;
	}

	public String getServiceStartDate() {
		return ServiceStartDate;
	}

	public void setServiceStartDate(String serviceStartDate) {
		ServiceStartDate = serviceStartDate;
	}

	public String getServiceEndDate() {
		return ServiceEndDate;
	}

	public void setServiceEndDate(String serviceEndDate) {
		ServiceEndDate = serviceEndDate;
	}
	
	public String getOrganizationCode() {
		return OrganizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		OrganizationCode = organizationCode;
	}

		public String getMemberHCID() {
		return MemberHCID;
	}

	public void setMemberHCID(String memberHCID) {
		MemberHCID = memberHCID;
	}

	
//	public String getMemberCode() {
//		return MemberCode;
//	}
//
//	public void setMemberCode(String memberCode) {
//		MemberCode = memberCode;
//	}
//
//	public String getMemberCase() {
//		return MemberCase;
//	}
//
//	public void setMemberCase(String memberCase) {
//		MemberCase = memberCase;
//	}
//
//	public String getMemberContract() {
//		return MemberContract;
//	}
//
//	public void setMemberContract(String memberContract) {
//		MemberContract = memberContract;
//	}

	public String getAccumStartDate() {
		return AccumStartDate;
	}

	public void setAccumStartDate(String accumStartDate) {
		AccumStartDate = accumStartDate;
	}

	public String getAccumEndDate() {
		return AccumEndDate;
	}

	public void setAccumEndDate(String accumEndDate) {
		AccumEndDate = accumEndDate;
	}

	public String getClaimNetwork() {
		return ClaimNetwork;
	}

	public void setClaimNetwork(String claimNetwork) {
		ClaimNetwork = claimNetwork;
	}

	public String getAccumName() {
		return AccumName;
	}

	public void setAccumName(String accumName) {
		AccumName = accumName;
	}

	public String getMemberTier() {
		return MemberTier;
	}

	public void setMemberTier(String memberTier) {
		MemberTier = memberTier;
	}

	public String getProviderTaxId() {
		return ProviderTaxId;
	}

	public void setProviderTaxId(String providerTaxId) {
		ProviderTaxId = providerTaxId;
	}

	public String getDiagnosisCode() {
		return DiagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		DiagnosisCode = diagnosisCode;
	}
	
	public String getScenarioName() {
		return ScenarioName;
	}

	public void setScenarioName(String ScenarioName) {
		this.ScenarioName = ScenarioName;
	}

}